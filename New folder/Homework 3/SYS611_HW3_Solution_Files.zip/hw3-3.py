"""
Homework 3-3: Dave's Candies.

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import the numpy package and refer to it as `np`
# see http://docs.scipy.org/doc/numpy/reference/ for documentation
import numpy as np

# import the scipy stats package and refer to it as `stats`
# see http://docs.scipy.org/doc/scipy/reference/stats.html for documentation
import scipy.stats as stats

# import the matplotlib pyplot package and refer to it as `plt`
# see http://matplotlib.org/api/pyplot_api.html for documentation
import matplotlib.pyplot as plt

# seed for the random number generator to get consistent results
RANDOM_SEED = 99
# number of experimental trials to run
NUM_TRIALS = 10000
# list of possible inventory options
INVENTORY_OPTIONS = [40, 50, 60, 70, 80, 90]   

def gen_demand():
    # generates demand using discrete process generator
    return np.random.randint(40, 91)

def get_profit(demand, inventory):
    # compute profit as derived state variable
    if demand <= inventory:
        # profit of 12.00 - 7.50 for each box demanded
        # loss of 7.50 - 6.00 for each box remaining in inventory
        profit = (12.00 - 7.50)*demand - (7.50 - 6.00)*(inventory - demand)
    else:
        # profit of 12.00 - 7.50 for each box in inventory
        profit = (12.00 - 7.50)*inventory
    
    # return the calculated profit
    return profit

# set the random number seed
np.random.seed(RANDOM_SEED)

# create arrays to store profits - note these are 2D arrays
profits = np.zeros((len(INVENTORY_OPTIONS), NUM_TRIALS))

# loop over each trial
for trial in range(NUM_TRIALS):
    # compute the discrete demand using the random number
    demand_disc = gen_demand()
    
    # loop over each enumerated inventory level
    for i, inventory in enumerate(INVENTORY_OPTIONS):
        # compute and save the profit using the discrete demand
        profits[i,trial] = get_profit(demand_disc, inventory)

plt.figure()
# plot inventory option vs. mean profit
# error bars show 95% confidence interval computed as 1.96*standard error
plt.errorbar(INVENTORY_OPTIONS, np.mean(profits, axis=1), 
         yerr=1.96*stats.sem(profits, axis=1), fmt='.-r')
plt.xlabel('Inventory Size')
plt.ylabel('Profit')
plt.savefig('hw3-3f.png')

for i, inventory in enumerate(INVENTORY_OPTIONS):
    print 'Expected profit for {:} boxes: {:.2f}'.format(inventory, np.mean(profits[i,:]))
    print '95% confidence interval for {:} boxes: {:.2f} +/- {:.2f}'.format(inventory,
            np.mean(profits[i,:]), 1.96*stats.sem(profits[i,:]))
    print ''