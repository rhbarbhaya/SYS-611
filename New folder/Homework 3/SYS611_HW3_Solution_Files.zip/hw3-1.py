"""
Homework 3-1: Cafe Java Arrivals.

@author: Paul T. Grogan <pgrogan@stevens.edu>
"""

# import the numpy package and refer to it as `np`
# see http://docs.scipy.org/doc/numpy/reference/ for documentation
import numpy as np

# import the matplotlib pyplot package and refer to it as `plt`
# see http://matplotlib.org/api/pyplot_api.html for documentation
import matplotlib.pyplot as plt

# import the scipy stats package and refer to it as `stats`
# see http://docs.scipy.org/doc/scipy/reference/stats.html for documentation
import scipy.stats as stats

# number of customers observed in 1 minute
customers = np.arange(0,7)

# record the number of observed customers
observed = [9, 26, 28, 15, 12, 5, 5]

# create the expected pmf based on the Poisson distribution 
expected = stats.poisson.pmf(customers, 2.5)*sum(observed)

# create a figure to plot the pmf data
plt.figure()
plt.bar(customers-0.2, observed, 0.4, color='b', label='Observed')
plt.bar(customers+0.2, expected, 0.4, color='g', label='Expected')
plt.xlabel('Number Customers in 1 minute ($x$)')
plt.ylabel('Frequency')
plt.legend(loc='best')
plt.savefig('hw3-1.png')

# compute the chi-squared test statistic by hand
N = np.sum(observed)
chisq_hand = np.sum(np.power(observed-expected,2)/expected)
print 'chi^2 = {:.2f}'.format(chisq_hand)

# perform the chi-squared test using the scipy function
chisq, p_chi = stats.chisquare(observed, expected)
print 'chi^2 = {:.2f}, p-value = {:.2f}'.format(chisq, p_chi)