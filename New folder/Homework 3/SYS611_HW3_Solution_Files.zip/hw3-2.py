"""
Homework 3-2: Cafe Java Service.

@author: Paul T. Grogan <pgrogan@stevens.edu>
"""

# import the numpy package and refer to it as `np`
# see http://docs.scipy.org/doc/numpy/reference/ for documentation
import numpy as np

# import the matplotlib pyplot package and refer to it as `plt`
# see http://matplotlib.org/api/pyplot_api.html for documentation
import matplotlib.pyplot as plt

# import the scipy stats package and refer to it as `stats`
# see http://docs.scipy.org/doc/scipy/reference/stats.html for documentation
import scipy.stats as stats

#%% question 3.2 - note this approach suffers from discontinuities

arrivals = [0.11, 0.19, 0.23, 0.26, 0.27, 0.35, 0.41, 0.48, 0.53, 0.77]

# create a fine-resolution list with 1000 points between 0 and 1
y = np.arange(0,1,0.001)

# compute the observed cdf using the definition of cdf and a python generator
obs_cdf = [sum(arrivals <= i)/float(len(arrivals)) for i in y]

# evaluate the expected cdf using the exponential distribution
exp_cdf = stats.expon.cdf(y, scale=1/2.5)

# create a figure to plot the cdf data
plt.figure()
plt.step(y, obs_cdf, '-b', where='post', label='Observed CDF')
plt.plot(y, exp_cdf, '-r', label='Exponential CDF')
plt.xlabel('Inter-arrival Time ($y$)')
plt.ylabel('Cumulative Probability ($P(y \\leq Y)$)')
plt.legend(loc='best')
plt.savefig('hw3-2c.png')

# compute the k-s test statistic by hand
ks_hand = np.max(np.abs(np.subtract(obs_cdf, exp_cdf)))
print 'k-s = {:.2f}'.format(ks_hand)
# note: this is off by 0.1 because it is evaluating the "wrong" side of the 
# discontinuities in observations - this is fixed below

# perform the k-s test using the scipy function
ks, p_ks = stats.kstest(arrivals, lambda i: stats.expon.cdf(i, scale=1/2.5))
print 'k-s = {:.2f}, p-value = {:.2f}'.format(ks, p_ks)